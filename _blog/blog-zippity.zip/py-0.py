name = 'John'
print 'Hello {0}'.format(name)
