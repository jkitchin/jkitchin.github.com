
print "Hello world"
