a = 5

def f(x,y):
    return x*b
