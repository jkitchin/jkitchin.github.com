
def special_func(x):
    return "J"
