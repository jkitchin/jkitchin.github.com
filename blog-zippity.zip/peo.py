
import sys

print >>sys.stdout, "on stdout"
print >>sys.stderr, "on stderr"
