
#!/bin/bash
{
bash $1
} 2>&1
