
5 + 5
 
exit % you have to always put this here or matlab will not exit
