course
======

This is where the syllabus and other course information will live.
