(define-package "kitchingroup-43" "20160130.1150" "preprint doi:10.1007/s11244-013-0166-3"
  '((cappa "0"))
  :authors
  '(("John Kitchin" . "jkitchin@andrew.cmu.edu"))
  :maintainer
  '("John Kitchin" . "jkitchin@andrew.cmu.edu"))
;; Local Variables:
;; no-byte-compile: t
;; End:
